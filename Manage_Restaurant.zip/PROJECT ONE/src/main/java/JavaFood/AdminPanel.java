package JavaFood;

import Models.Discount;
import Models.Food;
import Models.Order;
import Models.Restaurant;
import Users.Admin;
import Users.Customer;
import Users.RestaurantOwner;
import Users.User;
import com.google.gson.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;
import java.util.stream.Collectors;

public class AdminPanel {
    public static ArrayList<Restaurant> restaurants = new ArrayList<>();
    public static ArrayList<User> users = new ArrayList<>();
    public static ArrayList<Discount> discounts = new ArrayList<>();
    public static ArrayList<Order> orders = new ArrayList<>();
    public static LocalDate todayDate;

    public void loadFromJSONFile(String fileAddress) {
       try {
           Gson gson = new Gson();
           JsonObject root = JsonParser.parseReader(new FileReader(fileAddress)).getAsJsonObject();
           //1
           todayDate = LocalDate.parse(root.get("todayDate").getAsString());
           //2

           JsonArray restaurantArray = root.getAsJsonArray("restaurants");
           for (JsonElement restaurantElement : restaurantArray) {
               JsonObject obj = restaurantElement.getAsJsonObject();
               Integer id = obj.get("id").getAsInt();
               String name = obj.get("name").getAsString();
               String address = obj.get("address").getAsString();
               Integer openHour = obj.get("openHour").getAsInt();
               Integer closeHour = obj.get("closeHour").getAsInt();
               String type = obj.get("type").getAsString();

               Restaurant.RestaurantTypes restaurantType = Restaurant.RestaurantTypes.valueOf(type);
               Restaurant restaurant = new Restaurant(id, name, address, openHour, closeHour, restaurantType);

               if (obj.has("isOpen") && obj.get("isOpen").getAsBoolean()) {
                   restaurant.openRestaurant();
               }

               //3
               if (obj.has("foods")){
                   JsonArray foodArray = obj.getAsJsonArray("foods");
                   for (JsonElement foodElement : foodArray) {
                       JsonObject objFood = foodElement.getAsJsonObject();
                       int foodId = objFood.get("id").getAsInt();
                       String foodName = objFood.get("name").getAsString();
                       Double foodPrice = objFood.get("price").getAsDouble();
                       int foodQuantity = objFood.get("quantity").getAsInt();

                       Food food  = new Food(foodId, foodName, foodPrice);
                       restaurant.addFood(food, foodQuantity);
                   }
               }

               restaurants.add(restaurant);
           }

           JsonObject objUsers = root.getAsJsonObject("users");

               if (objUsers.has("restaurantOwners"))
               {
                   JsonArray restaurantOwnerArray = objUsers.getAsJsonArray("restaurantOwners");
                   for (JsonElement restaurantOwnerElement : restaurantOwnerArray) {
                       JsonObject objRestaurantOwner  = restaurantOwnerElement.getAsJsonObject();
                       Integer restaurantOwner = objRestaurantOwner.get("id").getAsInt();
                       String restaurantOwnerName = objRestaurantOwner.get("name").getAsString();

                       RestaurantOwner tmpRestaurantOwner = new RestaurantOwner(restaurantOwner, restaurantOwnerName);

                       if (objRestaurantOwner.has("ownedRestaurants"))
                       {
                           JsonArray ownedRestaurantsArray = objRestaurantOwner.getAsJsonArray("ownedRestaurants");
                           for (JsonElement ownedRestaurantElement : ownedRestaurantsArray) {
                               Integer restaurantOwnerId = ownedRestaurantElement.getAsInt();
                               Restaurant restaurant = restaurants.stream()
                                       .filter(r -> r.getId().equals(restaurantOwnerId))
                                       .findFirst()
                                       .orElse(null);

                               if (restaurant != null) {
                                   tmpRestaurantOwner.restaurants.add(restaurant);
                               }
                           }
                       }
                       users.add(tmpRestaurantOwner);
                   }
               } else if (objUsers.has("admins")) {
                   JsonArray adminsArray = objUsers.getAsJsonArray("admins");
                   for (JsonElement adminElement : adminsArray) {
                       JsonObject objAdmin = adminElement.getAsJsonObject();
                       Integer adminId = objAdmin.get("id").getAsInt();
                       String adminName = objAdmin.get("name").getAsString();
                       User tmpAdmin = new Admin(adminId, adminName);
                       users.add(tmpAdmin);
                   }
               } else if (objUsers.has("customers")) {
                   JsonArray customersArray = objUsers.getAsJsonArray("customers");
                   for (JsonElement customersElement : customersArray) {
                       JsonObject objCustomer = customersElement.getAsJsonObject();
                       Integer customerId = objCustomer.get("id").getAsInt();
                       String customerName = objCustomer.get("name").getAsString();
                       User tmpCustomer = new Customer(customerId, customerName);
                       users.add(tmpCustomer);
                   }
               }

           JsonArray discountArray = root.getAsJsonArray("discounts");
           for (JsonElement discountElement : discountArray) {
               JsonObject objDiscount = discountElement.getAsJsonObject();
               Integer discountId = objDiscount.get("id").getAsInt();
               String discountName = objDiscount.get("code").getAsString();
               double amount = 0;
               if(objDiscount.has("amount")){
                   amount = objDiscount.get("amount").getAsDouble();
               }
               int percentage=0;
               if (objDiscount.has("percentage")){
                   percentage = objDiscount.get("percentage").getAsInt();
               }
               String tmpExpireDate = objDiscount.get("expireDate").getAsString();
               LocalDate expireDate = LocalDate.parse(tmpExpireDate);
               Integer userId = objDiscount.get("userId").getAsInt();
               if(objDiscount.has("amount")){
                   Discount tmpDiscount1 = new Discount(discountId,
                           discountName,amount,expireDate,userId);
                   discounts.add(tmpDiscount1);
               }
               else if (objDiscount.has("percentage")){
                   Discount tmpDiscount1 = new Discount(discountId,
                           discountName,percentage,expireDate,userId);
                   discounts.add(tmpDiscount1);
               }

           }
           JsonArray orderArray = root.getAsJsonArray("orders");
           for (JsonElement orderElement : orderArray) {
               JsonObject objOrder = orderElement.getAsJsonObject();
               Integer orderId = objOrder.get("id").getAsInt();
               Integer userId = objOrder.get("userId").getAsInt();
               Integer restaurantId = objOrder.get("restaurantId").getAsInt();

               Restaurant targetRestaurant = restaurants.stream()
                       .filter(restaurant -> restaurant.getId().equals(restaurantId))
                       .findFirst()
                       .orElse(null);

               if (targetRestaurant == null) continue;

               String receivingType = objOrder.get("receivingType").getAsString();
               Order.ReceivingType tmpReceivingType = Order.ReceivingType.valueOf(receivingType);

               Order tmpOrder = new Order(orderId,userId,targetRestaurant,tmpReceivingType);

               JsonArray orderFoodArray = objOrder.getAsJsonArray("foods");
               for (JsonElement orderFoodElement : orderFoodArray) {
                   JsonObject objFood = orderFoodElement.getAsJsonObject();
                   Integer foodId = objFood.get("foodId").getAsInt();
                   Integer orderQuantity = objFood.get("quantity").getAsInt();
                   tmpOrder.addFoodToOrder(foodId,orderQuantity);
               }

               if (objOrder.has("discountCodes")) {
                   JsonArray orderDiscountArray = objOrder.getAsJsonArray("discountCodes");
                   for (JsonElement discountElem : orderDiscountArray) {
                       String discountCode = discountElem.getAsString();
                       tmpOrder.addDiscount(discountCode);
                   }
               }


               if(objOrder.has("isPaid")){
                   tmpOrder.setIsPaid(objOrder.get("isPaid").getAsBoolean());
               }
               if(objOrder.has("score")){
                   Integer score = objOrder.get("score").getAsInt();
                   tmpOrder.scoreOrder(score);
               }
               if(objOrder.has("payAmount")){
                   Double amount = objOrder.get("payAmount").getAsDouble();
                   tmpOrder.pay(amount);
               }
               orders.add(tmpOrder);
           }
      }
       catch (Exception e) {
           e.printStackTrace();
       }
    }

    public void addDiscount(Discount discount) {
        discounts.add(discount);
    }

    public void addUser(User user) {
        if(user != null)
            users.add(user);
    }

    public void addRestaurant(Restaurant restaurant) {
        if (restaurant != null)
            restaurants.add(restaurant);
    }

    public Order createOrder(Integer id, Integer userId, Integer restaurant_id, Order.ReceivingType type) {
        Restaurant tmpRestaurant = restaurants.stream()
                .filter(restaurant -> restaurant.getId() == restaurant_id)
                .findFirst()
                .orElse(null);
        if (tmpRestaurant == null) return null;
        else {
            return new Order(id, userId, tmpRestaurant, type);
        }
    }

    public void setDate(LocalDate todayDate) {
        if (todayDate != null)
            AdminPanel.todayDate = todayDate;
    }

    public Restaurant getBestRestaurant() {
        return  restaurants.stream()
                .max(Comparator.comparing(Restaurant :: getScore))
                .orElse(null);
    }

    public Restaurant getMostOrderedRestaurant() {
        return restaurants.stream()
                .max(Comparator.comparing(Restaurant :: getTodayOrdersCount))
                .orElse(null);
    }
}